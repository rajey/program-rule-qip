import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feature-module',
  templateUrl: './feature-module.component.html',
  styleUrls: ['./feature-module.component.css']
})
export class FeatureModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
